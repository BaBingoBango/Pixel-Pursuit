//
//  ARSceneID.swift
//  Pixel Pursuit
//
//  Created by Ethan Marshall on 4/18/23.
//

import Foundation

enum ARSceneID {
    case coaching
    case diskTable
    case office
    case disk
    case photos
    case desktop
    case webHistory
    case secretServer
}
